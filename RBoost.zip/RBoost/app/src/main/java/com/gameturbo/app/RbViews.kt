package com.gameturbo.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View

private fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

/** Bar RAM vertikal (biru di atas, merah di bawah) seperti desain R BOOST. */
class RamBar(ctx: Context) : View(ctx) {
    var frac = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var pct = "--%"
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = context.dpf(3f)
        rect.set(pad, pad, w - pad, h - pad)
        val r = rect.width() / 2f
        p.reset(); p.isAntiAlias = true
        p.style = Paint.Style.FILL; p.color = Color.BLACK
        c.drawRoundRect(rect, r, r, p)
        val save = c.save()
        path.reset(); path.addRoundRect(rect, r, r, Path.Direction.CW)
        c.clipPath(path)
        val fh = rect.height() * frac
        p.shader = LinearGradient(0f, rect.bottom - fh, 0f, rect.bottom, Color.parseColor("#1A1AAA"), Color.parseColor("#E01010"), Shader.TileMode.CLAMP)
        c.drawRect(rect.left, rect.bottom - fh, rect.right, rect.bottom, p)
        p.shader = null
        c.restoreToCount(save)
        p.style = Paint.Style.STROKE; p.strokeWidth = context.dpf(2f); p.color = Color.parseColor("#FF2A2A")
        p.setShadowLayer(context.dpf(6f), 0f, 0f, Color.RED)
        c.drawRoundRect(rect, r, r, p)
        p.clearShadowLayer()
        p.style = Paint.Style.FILL; p.color = Color.WHITE
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        p.textSize = w * 0.42f; p.textAlign = Paint.Align.CENTER
        c.save(); c.translate(w / 2f, rect.top + h * 0.16f); c.rotate(90f); c.drawText(pct, 0f, p.textSize * 0.35f, p); c.restore()
        c.save(); c.translate(w / 2f, rect.top + h * 0.62f); c.rotate(90f); c.drawText("RAM", 0f, p.textSize * 0.35f, p); c.restore()
    }
}

/** Slider horizontal (isi biru, sisa merah) untuk VOL dan kecerahan. */
class HBar(ctx: Context, private val label: String, private val onChange: (Float) -> Unit) : View(ctx) {
    var frac = 0.5f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = context.dpf(3f)
        rect.set(pad, pad, w - pad, h - pad)
        val r = context.dpf(8f)
        p.reset(); p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(rect.left, 0f, rect.right, 0f, Color.parseColor("#5A1010"), Color.parseColor("#D01818"), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, r, r, p)
        p.shader = null
        val save = c.save()
        c.clipRect(rect.left, rect.top, rect.left + rect.width() * frac, rect.bottom)
        p.shader = LinearGradient(rect.left, 0f, rect.right, 0f, Color.parseColor("#14108A"), Color.parseColor("#2A1AD0"), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, r, r, p)
        p.shader = null
        c.restoreToCount(save)
        p.style = Paint.Style.STROKE; p.strokeWidth = context.dpf(1.5f); p.color = Color.parseColor("#FF3030")
        p.setShadowLayer(context.dpf(5f), 0f, 0f, Color.RED)
        c.drawRoundRect(rect, r, r, p)
        p.clearShadowLayer()
        p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textSize = h * 0.42f
        p.typeface = Typeface.DEFAULT; p.textAlign = Paint.Align.LEFT
        c.drawText(label, rect.left + context.dpf(10f), h / 2f + p.textSize * 0.35f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val pad = context.dpf(3f)
                frac = ((e.x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
                onChange(frac)
            }
        }
        return true
    }
}

/** Bola gradien biru-merah dengan teks (RAM / SUHU) atau logo di tengah. */
class Orb(ctx: Context) : View(ctx) {
    var line1 = ""
        set(v) { field = v; invalidate() }
    var line2 = ""
        set(v) { field = v; invalidate() }
    var logo: Bitmap? = null
        set(v) { field = v; invalidate() }
    var circle = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = minOf(w, h) - context.dpf(8f)
        val cx = w / 2f
        val cy = h / 2f
        p.reset(); p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, cy - d / 2f, 0f, cy + d / 2f, Color.parseColor("#1E1AA0"), Color.parseColor("#D01010"), Shader.TileMode.CLAMP)
        p.setShadowLayer(context.dpf(8f), 0f, 0f, Color.parseColor("#FF2020"))
        if (circle) c.drawCircle(cx, cy, d / 2f, p)
        p.clearShadowLayer(); p.shader = null
        val lg = logo
        if (lg != null) {
            val s = if (circle) d * 0.62f else d * 1.0f
            val sc = s / maxOf(lg.width, lg.height).toFloat()
            val bw = lg.width * sc
            val bh = lg.height * sc
            c.drawBitmap(lg, null, RectF(cx - bw / 2f, cy - bh / 2f, cx + bw / 2f, cy + bh / 2f), p)
        } else {
            p.style = Paint.Style.FILL; p.color = Color.WHITE
            p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
            p.textAlign = Paint.Align.CENTER
            p.textSize = d * 0.30f
            c.drawText(line1, cx, cy - d * 0.02f, p)
            p.textSize = d * 0.24f
            c.drawText(line2, cx, cy + d * 0.26f, p)
        }
    }
}

/** Saklar: mati = trek gelap + kenop merah di kiri, nyala = trek oranye + kenop di kanan. */
class Tog(ctx: Context) : View(ctx) {
    var on = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = context.dpf(2f)
        rect.set(pad, pad, w - pad, h - pad)
        val r = rect.height() / 2.4f
        p.reset(); p.isAntiAlias = true
        p.style = Paint.Style.FILL
        if (on) p.shader = LinearGradient(rect.left, 0f, rect.right, 0f, Color.parseColor("#FF9A3C"), Color.parseColor("#C02A18"), Shader.TileMode.CLAMP)
        else p.color = Color.parseColor("#34343A")
        c.drawRoundRect(rect, r, r, p)
        p.shader = null
        val kw = rect.width() * 0.52f
        val kl = if (on) rect.right - kw else rect.left
        p.color = Color.parseColor("#D02020")
        c.drawRoundRect(RectF(kl, rect.top, kl + kw, rect.bottom), r, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = context.dpf(1f); p.color = Color.parseColor("#FF6060")
        c.drawRoundRect(RectF(kl, rect.top, kl + kw, rect.bottom), r, r, p)
    }
}
