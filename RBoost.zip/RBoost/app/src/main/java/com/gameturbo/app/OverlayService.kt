package com.gameturbo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Calendar
import kotlin.math.abs

/**
 * Floating window: garis tipis di ujung layar (kiri/kanan). Ketuk atau geser ke dalam
 * untuk membuka Smart Panel. Garis hanya muncul di atas game (kalau izin deteksi game aktif).
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { Games.prefs(this) }

    // jendela
    private var handle: FrameLayout? = null
    private var line: View? = null
    private lateinit var lpHandle: WindowManager.LayoutParams
    private var panel: View? = null
    private var lpPanel: WindowManager.LayoutParams? = null

    // isi panel
    private var tvFps: TextView? = null
    private var tvRam: TextView? = null
    private var tvCel: TextView? = null
    private var orbRam: Orb? = null
    private var orbTemp: Orb? = null
    private var ramBar: RamBar? = null
    private var aiMsg: TextView? = null
    private var btnBoost: Tog? = null
    private var logoBmp: Bitmap? = null
    private var modeViews: List<TextView> = emptyList()
    private var btnDnd: Tog? = null
    private var btnOn: View? = null
    private var eyeView: View? = null
    private var eyeOn = false
    private var curTab = 0

    // status
    private var gamePkg: String? = null
    private var gameSet: Set<String> = emptySet()
    private var gameSetAt = 0L
    private var rightSide = true
    private var mode = "bal"
    private var keepOn = false
    private var dndOn = false
    private var prevFilter = -1
    private var tickMs = 1000L

    // FPS layar
    private var frames = 0
    private var fps = 0
    private var maxFps = 60
    private var lastMs = 0L
    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            val now = frameTimeNanos / 1_000_000L
            if (lastMs == 0L) lastMs = now
            frames++
            val dt = now - lastMs
            if (dt >= 1000L) {
                fps = (frames * 1000L / dt).toInt()
                if (fps > maxFps && fps <= 165) maxFps = fps
                frames = 0
                lastMs = now
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            detectForeground()
            if (panel != null) refreshPanel()
            handler.postDelayed(this, tickMs)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        rightSide = prefs.getString("side", "right") == "right"
        mode = prefs.getString("mode", "bal") ?: "bal"
        tickMs = if (mode == "save") 3000L else 1000L
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        intent?.getStringExtra(EXTRA_GAME)?.let { gamePkg = it }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (handle == null) {
            buildHandle()
            handler.post(tick)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        Choreographer.getInstance().removeFrameCallback(frameCb)
        removePanel()
        setEye(false)
        handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handle = null
        if (dndOn) setDnd(false)
        super.onDestroy()
    }

    // ---------- util ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun screenH(): Int {
        if (Build.VERSION.SDK_INT >= 30) return wm.currentWindowMetrics.bounds.height()
        val m = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        return m.heightPixels
    }

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun baseFlags(): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (keepOn) f = f or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        return f
    }

    private fun sideGravity(): Int = Gravity.TOP or (if (rightSide) Gravity.END else Gravity.START)

    private fun toast(s: String) = Toast.makeText(applicationContext, s, Toast.LENGTH_SHORT).show()

    private fun openActivity(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("Tidak bisa dibuka dari sini")
        }
    }

    // ---------- notifikasi ----------

    private fun startAsForeground() {
        val channelId = "turbo"
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, "R BOOST", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("R BOOST aktif")
            .setContentText("Garis panel ada di tepi layar saat main game")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Matikan", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- garis di tepi layar ----------

    private fun lineParams(): FrameLayout.LayoutParams = FrameLayout.LayoutParams(
        dp(7), dp(120), Gravity.CENTER_VERTICAL or (if (rightSide) Gravity.END else Gravity.START)
    )

    private fun lineDrawable(): GradientDrawable {
        val r = dp(5).toFloat()
        return GradientDrawable().apply {
            setColor(Color.parseColor("#E0D3D3D3"))
            cornerRadii = if (rightSide) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r) else floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
        }
    }

    private fun buildHandle() {
        val box = FrameLayout(this)
        val l = View(this)
        l.background = lineDrawable()
        box.addView(l, lineParams())
        line = l

        lpHandle = WindowManager.LayoutParams(
            dp(24), dp(132), overlayType(), baseFlags(), PixelFormat.TRANSLUCENT
        ).apply {
            gravity = sideGravity()
            x = 0
            y = prefs.getInt("hy", dp(120))
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startY = 0
        var dragging = false
        var opened = false
        box.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startY = lpHandle.y
                    dragging = false; opened = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    val inward = if (rightSide) -dx else dx
                    if (!opened && !dragging && inward > dp(16) && abs(dx) > abs(dy)) {
                        opened = true
                        expand()
                    } else if (!opened && (dragging || (abs(dy) > slop && abs(dy) > abs(dx)))) {
                        dragging = true
                        lpHandle.y = (startY + dy).toInt().coerceIn(0, (screenH() - dp(132)).coerceAtLeast(0))
                        try { wm.updateViewLayout(box, lpHandle) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (opened) {
                        // sudah dibuka lewat geseran
                    } else if (dragging) {
                        prefs.edit().putInt("hy", lpHandle.y).apply()
                    } else {
                        expand()
                    }
                }
            }
            true
        }
        handle = box
        wm.addView(box, lpHandle)
    }

    private fun applySide() {
        prefs.edit().putString("side", if (rightSide) "right" else "left").apply()
        val h = handle ?: return
        lpHandle.gravity = sideGravity()
        line?.layoutParams = lineParams()
        line?.background = lineDrawable()
        try { wm.updateViewLayout(h, lpHandle) } catch (_: Exception) {}
    }

    private fun applyKeepOn() {
        try {
            handle?.let { lpHandle.flags = baseFlags(); wm.updateViewLayout(it, lpHandle) }
            panel?.let { p -> lpPanel?.let { it.flags = panelFlags(); wm.updateViewLayout(p, it) } }
        } catch (_: Exception) {}
    }

    // ---------- deteksi game di depan ----------

    private fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        @Suppress("DEPRECATION")
        val m = ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        return m == android.app.AppOpsManager.MODE_ALLOWED
    }

    @Suppress("DEPRECATION")
    private fun foregroundPkg(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(now - 15000L, now)
        val e = UsageEvents.Event()
        var last: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
        }
        return last
    }

    private fun detectForeground() {
        val h = handle ?: return
        if (!prefs.getBoolean("auto", true) || !hasUsage()) {
            if (h.visibility != View.VISIBLE) h.visibility = View.VISIBLE
            return
        }
        val fg = foregroundPkg() ?: return
        val nowMs = System.currentTimeMillis()
        if (nowMs - gameSetAt > 30000L) {
            gameSet = Games.gamePackages(this); gameSetAt = nowMs
        }
        val isGame = fg in gameSet
        if (isGame) gamePkg = fg
        if (isGame) {
            if (h.visibility != View.VISIBLE) h.visibility = View.VISIBLE
        } else {
            if (panel != null) collapse()
            if (h.visibility != View.GONE) h.visibility = View.GONE
        }
    }

    // ---------- panel ----------

    private fun panelFlags(): Int = baseFlags() or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH

    private fun txt(s: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun round(color: Int, r: Int, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(r).toFloat()
            if (strokeW > 0) setStroke(strokeW, strokeColor)
        }

    private fun setActive(v: View?, on: Boolean) {
        (v as? Tog)?.on = on
    }

    private val red = Color.parseColor("#E81818")

    private fun redText(s: String, size: Float, align: Int = Gravity.START): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(red)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
            gravity = align
            setShadowLayer(dp(5).toFloat(), 0f, 0f, Color.parseColor("#FF2020"))
        }

    private fun logoBitmap(): Bitmap? {
        if (logoBmp == null) {
            logoBmp = try { assets.open("logo.png").use { BitmapFactory.decodeStream(it) } } catch (_: Exception) { null }
        }
        return logoBmp
    }

    private fun screenW(): Int {
        if (Build.VERSION.SDK_INT >= 30) return wm.currentWindowMetrics.bounds.width()
        val m = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        return m.widthPixels
    }

    private fun panelBg(): GradientDrawable =
        GradientDrawable().apply {
            setColor(Color.parseColor("#101014")); cornerRadius = dp(14).toFloat()
            setStroke(dp(1), Color.parseColor("#66FF2020"))
        }

    private fun toggleRow(title: String, initial: Boolean, onToggle: (Tog, Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(3), 0, dp(3))
        }
        val tv = redText(title, 9.5f, Gravity.END)
        row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val tg = Tog(this)
        tg.on = initial
        row.addView(tg, LinearLayout.LayoutParams(dp(46), dp(22)).apply { leftMargin = dp(8) })
        val click = View.OnClickListener { onToggle(tg, !tg.on) }
        row.setOnClickListener(click)
        tg.setOnClickListener(click)
        return row
    }

    private fun savePref(key: String, v: Boolean, msg: String, tg: Tog) {
        prefs.edit().putBoolean(key, v).apply()
        tg.on = v
        toast(msg)
    }

    private fun appIcon(pkg: String): android.graphics.drawable.Drawable? =
        try { packageManager.getApplicationIcon(pkg) } catch (_: Exception) { null }

    private fun shortcuts(): MutableList<String> {
        val saved = prefs.getString("rb_sc", null)
        if (saved != null) return saved.split(",").filter { it.isNotBlank() }.toMutableList()
        val defaults = listOf("com.whatsapp", "com.google.android.youtube", "com.zhiliaoapp.musically", "com.instagram.android")
        return defaults.filter { packageManager.getLaunchIntentForPackage(it) != null }.take(3).toMutableList()
    }

    private fun saveShortcuts(l: List<String>) = prefs.edit().putString("rb_sc", l.joinToString(",")).apply()

    private fun buildLeftMain(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(6), dp(8), dp(6)) }

        val orbs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val o1 = Orb(this).also { it.line1 = "RAM"; it.line2 = "--%" }
        val o2 = Orb(this).also { it.line1 = "SUHU"; it.line2 = "--°" }
        orbRam = o1; orbTemp = o2
        orbs.addView(o1, LinearLayout.LayoutParams(dp(60), dp(60)))
        orbs.addView(redText("⚡", 22f, Gravity.CENTER), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        orbs.addView(o2, LinearLayout.LayoutParams(dp(60), dp(60)))
        col.addView(orbs)

        col.addView(redText("GAME MODE SETTING", 9.5f, Gravity.END).apply { setPadding(0, dp(6), 0, dp(2)) })

        col.addView(toggleRow("AUTO PANEL CONTROL\nGYRO", prefs.getBoolean("rb_gyro", false)) { tg, v ->
            savePref("rb_gyro", v, "Tersimpan sebagai preferensi", tg)
        })
        val boost = toggleRow("BOOST UP FPS GAME TURBO\nSMART PANEL CONTROL", mode == "perf") { tg, v ->
            setMode(if (v) "perf" else "bal", true); tg.on = v
        }
        btnBoost = boost.getChildAt(1) as Tog
        col.addView(boost)
        col.addView(toggleRow("GYRO DINAMIC POWERED\nSTABILITY", prefs.getBoolean("rb_stab", false)) { tg, v ->
            savePref("rb_stab", v, "Tersimpan sebagai preferensi", tg)
        })
        val ext = toggleRow("AKTIFKAN MODE EKSTERNAL\n(JANGAN GANGGU)", dndOn) { tg, _ -> toggleDnd(); tg.on = dndOn }
        btnDnd = ext.getChildAt(1) as Tog
        col.addView(ext)
        col.addView(toggleRow("BYPASS CHARGING", prefs.getBoolean("rb_bypass", false)) { tg, v ->
            savePref("rb_bypass", v, "Bypass charging butuh dukungan hardware HP. Tersimpan sebagai preferensi.", tg)
        })

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, 0) }
        val stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sf = redText("FPS:--", 13f); val sr = redText("RAM:--GB", 13f); val sc = redText("CEL:--°C", 13f)
        tvFps = sf; tvRam = sr; tvCel = sc
        stats.addView(sf); stats.addView(sr); stats.addView(sc)
        bottom.addView(stats, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val lg = Orb(this).also { it.logo = logoBitmap(); it.circle = false }
        bottom.addView(lg, LinearLayout.LayoutParams(dp(64), dp(64)))
        col.addView(bottom)

        return ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) }
    }

    private fun buildPicker(onDone: () -> Unit): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        col.addView(redText("‹ PILIH APP UNTUK PINTASAN", 11f).apply { setPadding(0, 0, 0, dp(6)); setOnClickListener { onDone() } })
        val apps = try { Games.launchable(this) } catch (_: Exception) { emptyList() }
        apps.sortedBy { it.second.lowercase() }.forEach { (pkg, name) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
                setOnClickListener {
                    val l = shortcuts()
                    if (pkg !in l) { l.add(pkg); while (l.size > 4) l.removeAt(0); saveShortcuts(l) }
                    onDone()
                }
            }
            val iv = android.widget.ImageView(this)
            iv.setImageDrawable(appIcon(pkg))
            row.addView(iv, LinearLayout.LayoutParams(dp(28), dp(28)))
            row.addView(txt(name, 12f, Color.WHITE).apply { setPadding(dp(8), 0, 0, 0) })
            col.addView(row)
        }
        return ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) }
    }

    private fun buildLeftPanel(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = panelBg() }
        val bar = RamBar(this)
        ramBar = bar
        root.addView(bar, LinearLayout.LayoutParams(dp(34), LinearLayout.LayoutParams.MATCH_PARENT).apply { setMargins(dp(8), dp(10), 0, dp(10)) })

        val sc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(6), dp(8), dp(2), dp(8)) }
        val body = FrameLayout(this)
        fun showMain() { body.removeAllViews(); body.addView(buildLeftMain()) }
        fun fillShortcuts() {
            sc.removeAllViews()
            sc.addView(txt("+", 22f, Color.parseColor("#8A8A92")).apply {
                gravity = Gravity.CENTER
                setOnClickListener { body.removeAllViews(); body.addView(buildPicker { showMain(); fillShortcuts() }) }
            }, LinearLayout.LayoutParams(dp(40), dp(34)))
            shortcuts().forEach { pkg ->
                val iv = android.widget.ImageView(this)
                iv.setImageDrawable(appIcon(pkg))
                iv.setOnClickListener {
                    val i = packageManager.getLaunchIntentForPackage(pkg)
                    if (i != null) { collapse(); openActivity(i) }
                }
                iv.setOnLongClickListener {
                    val l = shortcuts(); l.remove(pkg); saveShortcuts(l); fillShortcuts(); toast("Pintasan dihapus"); true
                }
                sc.addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)).apply { topMargin = dp(8) })
            }
        }
        fillShortcuts()
        root.addView(sc, LinearLayout.LayoutParams(dp(54), LinearLayout.LayoutParams.MATCH_PARENT))
        showMain()
        root.addView(body, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
        return root
    }

    private fun aiAnalyze() {
        val ram = Booster.ramPercent(this)
        val temp = Booster.batteryTempC(this)
        val bat = Booster.batteryPercent(this)
        val sb = StringBuilder()
        if (ram >= 75) {
            sb.append("RAM terpakai $ram%. Aku tutup app background sekarang. ")
            doClean()
        } else sb.append("RAM $ram%, masih lega. ")
        if (temp != null && temp >= 40f) sb.append("Suhu %.0f°C lumayan panas, turunkan kecerahan atau istirahat sebentar. ".format(temp))
        else if (temp != null) sb.append("Suhu %.0f°C aman. ".format(temp))
        if (bat in 0..20) sb.append("Baterai tinggal $bat%, pakai mode Hemat Daya atau colok charger. ")
        if (fps in 1..45) sb.append("FPS layar rendah ($fps), coba mode Performa. ")
        if (ram < 75 && (temp == null || temp < 40f) && bat > 20) sb.append("Kondisi bagus, siap main!")
        aiMsg?.text = sb.toString().trim()
    }

    private fun buildRightPanel(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val am = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val maxV = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val vol = HBar(this, "VOL") { f ->
            try { am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (f * maxV).toInt(), 0) } catch (_: Exception) {}
        }
        vol.frac = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) / maxV.toFloat()
        col.addView(vol, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(34)))

        val curB = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (_: Exception) { 128 }
        val bri = HBar(this, "kec") { f ->
            if (!Settings.System.canWrite(this)) {
                toast("Izinkan \"Ubah pengaturan sistem\" di app R BOOST dulu")
            } else {
                try {
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, (f * 255).toInt().coerceAtLeast(5))
                } catch (_: Exception) {}
            }
        }
        bri.frac = curB / 255f
        col.addView(bri, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(34)).apply { topMargin = dp(6) })

        col.addView(redText("AI ASISTEN", 15f, Gravity.CENTER).apply { setTextColor(Color.parseColor("#3A34E0")); setPadding(0, dp(6), 0, dp(2)) })
        val orb = Orb(this).also { it.logo = logoBitmap() }
        orb.setOnClickListener { aiAnalyze() }
        col.addView(orb, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(118)))
        val msg = txt("Ketuk logo untuk analisis cepat.", 10f, Color.parseColor("#E8C8C8")).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) }
        aiMsg = msg
        col.addView(msg)
        return ScrollView(this).apply { isVerticalScrollBarEnabled = false; background = panelBg(); addView(col) }
    }

    private fun expand() {
        if (panel != null) return
        val sw = screenW()
        val width = minOf(sw - dp(8), dp(560))
        val container = FrameLayout(this).apply {
            setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) { collapse(); true } else false }
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(buildLeftPanel(), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1.75f))
        row.addView(buildRightPanel(), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { leftMargin = dp(8) })
        container.addView(row, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val lp = WindowManager.LayoutParams(
            width, (screenH() - dp(16)).coerceAtLeast(dp(200)),
            overlayType(), panelFlags(), PixelFormat.TRANSLUCENT
        ).apply { gravity = sideGravity(); x = dp(4); y = dp(8) }
        lpPanel = lp
        panel = container
        wm.addView(container, lp)
        handle?.visibility = View.INVISIBLE

        // muncul dari ujung layar
        val from = if (rightSide) width.toFloat() else -width.toFloat()
        row.translationX = from
        row.alpha = 0f
        row.animate().translationX(0f).alpha(1f).setDuration(240L).start()

        lastMs = 0L; frames = 0
        Choreographer.getInstance().postFrameCallback(frameCb)
        refreshPanel()
    }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; lpPanel = null
        Choreographer.getInstance().removeFrameCallback(frameCb)
        tvFps = null; tvRam = null; tvCel = null; orbRam = null; orbTemp = null; ramBar = null
        aiMsg = null; btnBoost = null; btnDnd = null; btnOn = null
    }

    private fun collapse() {
        removePanel()
        handle?.let { if (it.visibility == View.INVISIBLE) it.visibility = View.VISIBLE }
    }

    private fun refreshPanel() {
        val ram = Booster.ramPercent(this)
        val temp = Booster.batteryTempC(this)
        val mi = Booster.memInfo(this)
        val usedGb = (mi.totalMem - mi.availMem) / 1073741824.0
        ramBar?.apply { frac = ram / 100f; pct = "$ram%" }
        orbRam?.line2 = "$ram%"
        orbTemp?.line2 = if (temp != null) "%.0f°".format(temp) else "--"
        tvFps?.text = if (fps > 0) "FPS:$fps" else "FPS:--"
        tvRam?.text = "RAM:%.1fGB".format(usedGb)
        tvCel?.text = if (temp != null) "CEL:%.1f°C".format(temp) else "CEL:--"
    }

    // ---------- aksi ----------

    private fun updateModeUi() {
        btnBoost?.on = (mode == "perf")
    }

    private fun setMode(m: String, byUser: Boolean) {
        mode = m
        prefs.edit().putString("mode", m).apply()
        tickMs = if (m == "save") 3000L else 1000L
        updateModeUi()
        if (!byUser) return
        when (m) {
            "perf" -> {
                keepOn = true; applyKeepOn(); setActive(btnOn, true)
                doClean()
                if (nm().isNotificationPolicyAccessGranted) { setDnd(true); setActive(btnDnd, true) }
                toast("Mode Performa: layar tetap menyala, memori dibersihkan")
            }
            "save" -> { toast("Mode Hemat Daya: pembaruan panel diperlambat") }
            else -> toast("Mode Seimbang")
        }
    }

    private fun nm() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun doClean() {
        val before = Booster.memInfo(this).availMem
        val n = Booster.boost(this, setOfNotNull(gamePkg))
        toast("Menutup $n app di background...")
        handler.postDelayed({
            val freed = (Booster.memInfo(this).availMem - before) / 1048576L
            toast(if (freed > 0) "Selesai, RAM kosong naik sekitar $freed MB" else "Selesai, RAM kamu sudah lega")
        }, 1300L)
    }

    private fun openWifi() {
        collapse()
        val action = if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS
        openActivity(Intent(action))
    }

    private fun setDnd(on: Boolean) {
        val n = nm()
        if (!n.isNotificationPolicyAccessGranted) return
        if (on) {
            if (prevFilter == -1) prevFilter = n.currentInterruptionFilter
            n.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        } else if (prevFilter >= 1) {
            n.setInterruptionFilter(prevFilter); prevFilter = -1
        }
        dndOn = on
    }

    private fun toggleDnd() {
        if (!nm().isNotificationPolicyAccessGranted) {
            toast("Izinkan akses Jangan Ganggu untuk R BOOST dulu")
            collapse()
            openActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return
        }
        setDnd(!dndOn)
        setActive(btnDnd, dndOn)
        toast(if (dndOn) "Jangan Ganggu aktif" else "Jangan Ganggu mati")
    }

    private fun toggleKeepOn() {
        keepOn = !keepOn
        applyKeepOn()
        setActive(btnOn, keepOn)
        toast(if (keepOn) "Layar tetap menyala" else "Layar boleh mati sendiri")
    }

    companion object {
        const val ACTION_STOP = "com.gameturbo.app.STOP"
        const val EXTRA_GAME = "game"
        private const val NOTIF_ID = 2001

        @Volatile
        var running = false

        fun start(ctx: Context, gamePkg: String?) {
            val i = Intent(ctx, OverlayService::class.java)
            if (gamePkg != null) i.putExtra(EXTRA_GAME, gamePkg)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }
    }
}
